American Roulette Pro - Android project
========================================
Features:
- American wheel numbers 0, 00, 1-36
- Virtual balance and selectable chips ₹10-₹1,000
- Multiple number bets per round
- Automatic 30-second betting rounds, then automatic spin
- Winning straight-up bet returns 36x total (35:1 profit plus stake)
- Recent result history

Build APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync (Android Gradle Plugin 8.7.3; compile SDK 35).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK will be under app/build/outputs/apk/debug/app-debug.apk

This is a virtual-money demo only. No real-money deposits, withdrawals, or payments.
The wheel result is randomly generated locally; it is not connected to a live casino.
